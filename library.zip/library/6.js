




var body="";
  req.on('data', function (chunk) {
    body += chunk;
  });
  req.on('end', function () {
    console.log('POSTed: ' + body);
	var parse = JSON.parse(body);
	res.write(`welcome ${parse.username}`);
	res.end();
	
  });
  
  
    