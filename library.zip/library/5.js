

var body="";
  req.on('data', function (chunk) {
    body += chunk;
  });
  req.on('end', function () {
	
	fs.writeFileSync('borrowdata.json', body);
	res.end();
	
  });
  
  
    