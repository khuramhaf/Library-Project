

var body="";
  req.on('data', function (chunk) {
    body += chunk;
  });
  req.on('end', function () {
	
	fs.writeFileSync('initialdata.json', body);
	res.end();
	
  });
  
  
    