const fs = require('fs')

class books {
  constructor(bookname, author, studentname, dateofborrowing, dateofreturn) {
    this.bookname = bookname;
    this.author = author;
	this.studentname = studentname;
	this.dateofborrowing = dateofborrowing;
	this.dateofreturn = dateofreturn;
  }
}


var body="";
  req.on('data', function (chunk) {
    body += chunk;
  });
  req.on('end', function () {
	
	
	
	const data = fs.readFileSync('initialdata.json');
	const parser = JSON.parse(data);
	
	var array = [];
	
	
	
	var x =  0;
	while (x<parser.length){
	
	var datademand = new books(parser[x].bookname, parser[x].author, parser[x].studentname, parser[x].dateofborrowing, parser[x].dateofreturn);
	array.push(datademand);
	
	x++;
	}
	
	var parser1 = JSON.parse(body);
	
	
	var datademand1 = new books(parser1.bookname, parser1.author, parser1.studentname, parser1.dateofborrowing, parser1.dateofreturn);
	
	array.push(datademand1);
	
	var stringify = JSON.stringify(array);
	
	 fs.writeFileSync('initialdata.json', stringify);
	
	
	res.end();
	
  });
  
  
    